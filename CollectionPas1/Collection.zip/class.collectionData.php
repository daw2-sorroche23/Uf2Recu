<?php
require_once('class.collection.php');

class DataCollection extends collection{
  private $DatabaseArray = array();    

  private $_onload;               

  private $_isLoaded = false;     

 
}


?>
