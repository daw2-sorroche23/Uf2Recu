<?php
require_once('class.collection.php');

class VentanaCollection extends collection{
  private $Puertas = array();    

  private $_onload;               

  private $_isLoaded = false;     

}


?>
