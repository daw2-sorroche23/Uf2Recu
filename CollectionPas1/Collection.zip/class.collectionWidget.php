<?php
require_once('class.collection.php');

class WidgetCollection extends collection{
  private $WidgetArray = array();    

  private $_onload;               

  private $_isLoaded = false;     

}


?>
